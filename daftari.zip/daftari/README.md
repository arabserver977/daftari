# دفتري — دفتر الكريدي للمحلات الصغيرة

تطبيق Flutter. الزبائن والديون محفوظة على الجوال (SQLite) وتشتغل بدون إنترنت.

## الميزات
- قائمة الزبائن مع رصيد كل واحد وإجمالي الديون وملخص اليوم
- دين جديد / تسديد بضغطتين، تسديد كامل بزر واحد، وزر «تراجع» بعد الحفظ
- فلترة: الكل / عليهم ديون / مسدّدون، وشارة «متأخر» بعد 30 يوم
- تذكير جاهز عبر واتساب أو SMS، وزر اتصال
- الدخول بالإيميل مع كود تأكيد
- المظهر من الإعدادات: تلقائي / فاتح / داكن، و6 ألوان للاختيار

## التشغيل
```bash
# 1) داخل مجلد المشروع: يولّد مجلدات android و ios
flutter create . --platforms=android,ios --project-name daftari --org com.yourname

# 2) الحزم
flutter pub get

# 3) أيقونة التطبيق من assets/icon.png
dart run flutter_launcher_icons

# 4) تشغيل
flutter run
```

## إعدادات أندرويد (مهم)
افتح `android/app/src/main/AndroidManifest.xml` وأضف داخل `<manifest>` (خارج وسم `<application>`):
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<queries>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="sms"/></intent>
  <intent><action android:name="android.intent.action.DIAL"/><data android:scheme="tel"/></intent>
</queries>
```
سطر INTERNET ضروري، وبدونه الدخول بالإيميل وجلب بيانات الرابط ما يشتغلون في نسخة الإصدار (release).
التطبيق لا يطلب إذن الموقع أبدًا.

## تسجيل الدخول بالإيميل (Supabase)
المستخدم يكتب إيميله، يوصله كود، يكتبه ويدخل. الخطوات مرة واحدة منك:
1. أنشئ مشروعًا مجانيًا في supabase.com.
2. من Project Settings > API انسخ Project URL و anon public key والصقهما في `lib/config.dart`.
   قبل ما تلصقهما يشتغل التطبيق بدون تسجيل دخول (للتجربة المحلية).
3. من SQL Editor شغّل محتوى `supabase/setup.sql` (ينشئ جدول المحلات مع الحماية).
4. من Authentication > Emails (Email Templates) عدّل قالبين: **Confirm signup** و **Magic Link**.
   اجعل نص الرسالة يحتوي `{{ .Token }}` حتى يوصل الكود نفسه، مثال:
   `كود الدخول إلى دفتري: {{ .Token }}`
5. قبل الإطلاق: الإرسال الافتراضي من Supabase محدود جدًا ومخصص للتجربة.
   فعّل SMTP خاص من Authentication > Emails > SMTP Settings (مثل Resend أو Brevo)
   حتى يوصل الكود لكل المستخدمين بسرعة.
6. تشوف كل المحلات المسجّلة (الاسم، الهاتف، المدينة، الرابط، الموقع) من Table Editor > shops.

## تسجيل المحل
بعد الدخول يكتب صاحب المحل بياناته بنفسه: الاسم، الهاتف، النوع، المدينة، العنوان.
إذا لصق رابط محله من خرائط جوجل وضغط «جلب البيانات»، يأخذ التطبيق منه اسم المحل وإحداثياته.
الروابط المختصرة (maps.app.goo.gl) تُفتح تلقائيًا، وأحيانًا يرفض جوجل ذلك، وقتها يكتب البيانات يدويًا.
بيانات المحل تُرسل إلى Supabase بعد التسجيل. الزبائن والديون ما زالت على الجوال فقط،
والنسخة الاحتياطية لها خطوة لاحقة.

## ملاحظات
- رقم الزبون لازم يكون برمز الدولة (مثال: 2137xxxxxxxx) حتى يشتغل واتساب.
- خط Cairo يتحمّل أول مرة من الإنترنت ثم يُخزَّن. لو تبغاه مدمج بالتطبيق نضيفه في assets.
- ملفات الشعار: `assets/logo_full.svg` (الشعار الكامل)، `assets/mark.svg` (داخل التطبيق)، `assets/icon.png` (أيقونة التطبيق).
