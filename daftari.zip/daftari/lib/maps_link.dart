import 'package:http/http.dart' as http;

/// معلومات مأخوذة من رابط محل في خرائط جوجل.
class MapsInfo {
  const MapsInfo({this.name, this.lat, this.lng});

  final String? name;
  final double? lat;
  final double? lng;
}

final _coordPair =
    RegExp(r'^\s*(-?\d{1,3}(?:\.\d+)?)\s*[,،]\s*(-?\d{1,3}(?:\.\d+)?)\s*$');
final _pin = RegExp(r'!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)');
final _view = RegExp(r'@(-?\d+\.\d+),(-?\d+\.\d+)');

bool _valid(double a, double b) => a.abs() <= 90 && b.abs() <= 180;

List<double>? _coords(RegExpMatch? m) {
  if (m == null) return null;
  final a = double.tryParse(m.group(1)!);
  final b = double.tryParse(m.group(2)!);
  if (a == null || b == null || !_valid(a, b)) return null;
  return [a, b];
}

/// يقرأ رابط خرائط جوجل الكامل (أو إحداثيات مكتوبة مثل 36.75, 3.05).
/// يرجع null إذا لم يكن الرابط من خرائط جوجل.
MapsInfo? parseMapsUrl(String raw) {
  final text = raw.trim();

  final pair = _coords(_coordPair.firstMatch(text));
  if (pair != null) return MapsInfo(lat: pair[0], lng: pair[1]);

  final uri = Uri.tryParse(text);
  if (uri == null || !uri.hasAuthority) return null;
  final host = uri.host.toLowerCase();
  if (!host.contains('google.')) return null;

  // صفحة الموافقة تحمل الرابط الأصلي في المعامل continue.
  final cont = uri.queryParameters['continue'];
  if (host.startsWith('consent.') && cont != null) return parseMapsUrl(cont);

  String? name;
  final segs = uri.pathSegments;
  final i = segs.indexOf('place');
  if (i >= 0 && i + 1 < segs.length) {
    final s = segs[i + 1].replaceAll('+', ' ').trim();
    if (s.isNotEmpty &&
        !s.startsWith('@') &&
        _coordPair.firstMatch(s) == null) {
      name = s;
    }
  }

  final q = uri.queryParameters['q'] ??
      uri.queryParameters['query'] ??
      uri.queryParameters['ll'];
  final qCoords = q == null ? null : _coords(_coordPair.firstMatch(q));
  if (name == null && q != null && qCoords == null && q.trim().isNotEmpty) {
    name = q.trim();
  }

  // !3d !4d هو موقع المحل نفسه، و @ هو مركز الخريطة المعروضة.
  final c = _coords(_pin.firstMatch(text)) ??
      qCoords ??
      _coords(_view.firstMatch(text));

  if (name == null && c == null) return null;
  return MapsInfo(name: name, lat: c?[0], lng: c?[1]);
}

/// مثل parseMapsUrl، ويفتح الروابط المختصرة (maps.app.goo.gl) بالإنترنت.
Future<MapsInfo?> resolveMapsLink(String raw) async {
  final uri = Uri.tryParse(raw.trim());
  final host = uri?.host.toLowerCase() ?? '';
  final isShort = host == 'goo.gl' || host.endsWith('.goo.gl');
  if (uri == null || !isShort) return parseMapsUrl(raw);

  final client = http.Client();
  try {
    var current = uri;
    for (var i = 0; i < 6; i++) {
      final req = http.Request('GET', current)..followRedirects = false;
      final res = await client.send(req).timeout(const Duration(seconds: 8));
      await res.stream.drain<void>();
      final loc = res.headers['location'];
      if (res.isRedirect && loc != null) {
        current = current.resolve(loc);
        continue;
      }
      break;
    }
    return parseMapsUrl(current.toString());
  } catch (_) {
    return null;
  } finally {
    client.close();
  }
}
