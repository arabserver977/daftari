/// بيانات مشروعك في Supabase (موقع supabase.com).
/// من Project Settings > API: انسخ Project URL و anon public key والصقهما هنا.
/// مفتاح anon مصمم ليكون ظاهرًا في التطبيق، وحماية البيانات تتم بسياسات SQL الموجودة في supabase/setup.sql.
const supabaseUrl = 'PASTE_YOUR_SUPABASE_URL';
const supabaseAnonKey = 'PASTE_YOUR_SUPABASE_ANON_KEY';

/// إذا لم تلصق البيانات بعد، يشتغل التطبيق بدون تسجيل دخول (للتجربة المحلية فقط).
bool get authEnabled => !supabaseUrl.startsWith('PASTE');
