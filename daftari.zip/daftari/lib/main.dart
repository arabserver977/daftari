import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ar');
  if (authEnabled) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  final prefs = await SharedPreferences.getInstance();
  final store = Store(prefs);
  await store.load();
  if (store.registered) store.syncProfile();
  runApp(DaftariApp(store: store));
}

/// يقرر أي شاشة تظهر: الدخول بالإيميل، ثم تسجيل المحل، ثم الدفتر.
class _AuthGate extends StatelessWidget {
  const _AuthGate({required this.store});

  final Store store;

  Widget _app() => store.registered
      ? HomeScreen(store: store)
      : RegisterScreen(store: store);

  @override
  Widget build(BuildContext context) {
    if (!authEnabled) return _app();
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, _) {
        final signedIn = Supabase.instance.client.auth.currentSession != null;
        return signedIn ? _app() : const LoginScreen();
      },
    );
  }
}

ThemeMode _modeOf(String s) {
  switch (s) {
    case 'light':
      return ThemeMode.light;
    case 'dark':
      return ThemeMode.dark;
    default:
      return ThemeMode.system;
  }
}

class DaftariApp extends StatelessWidget {
  const DaftariApp({super.key, required this.store});

  final Store store;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final accent =
            accents[store.accentIndex.clamp(0, accents.length - 1).toInt()];
        AppColors.current = accent;
        return MaterialApp(
          title: 'دفتري',
          debugShowCheckedModeBanner: false,
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: buildTheme(Brightness.light, accent),
          darkTheme: buildTheme(Brightness.dark, accent),
          themeMode: _modeOf(store.themeMode),
          home: _AuthGate(store: store),
        );
      },
    );
  }
}
