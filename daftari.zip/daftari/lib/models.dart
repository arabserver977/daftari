class Customer {
  Customer({
    required this.id,
    required this.name,
    required this.phone,
    required this.balance,
    required this.lastActivity,
  });

  final int id;
  final String name;
  final String phone;

  /// موجب = على الزبون دين، سالب = له رصيد عندك.
  final double balance;
  final DateTime lastActivity;
}

class Txn {
  Txn({
    required this.id,
    required this.customerId,
    required this.amount,
    required this.note,
    required this.createdAt,
  });

  final int id;
  final int customerId;

  /// موجب = دين جديد، سالب = تسديد.
  final double amount;
  final String note;
  final DateTime createdAt;

  bool get isDebt => amount > 0;
}

class TxnInput {
  TxnInput(this.amount, this.note);
  final double amount;
  final String note;
}
