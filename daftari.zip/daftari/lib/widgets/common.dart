import 'package:flutter/material.dart';

import 'package:supabase_flutter/supabase_flutter.dart' show Supabase;

import '../config.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../utils.dart';

InputDecoration fieldDecoration(
  BuildContext context,
  String label, {
  String? hint,
  Widget? prefix,
  String? suffixText,
  String? errorText,
}) {
  final fill = context.ink.withOpacity(context.isDark ? 0.07 : 0.045);
  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: c, width: w),
      );
  return InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: prefix,
    suffixText: suffixText,
    errorText: errorText,
    filled: true,
    fillColor: fill,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    border: border(Colors.transparent),
    enabledBorder: border(Colors.transparent),
    focusedBorder: border(context.brand, 1.6),
    errorBorder: border(context.debtColor),
    focusedErrorBorder: border(context.debtColor, 1.6),
  );
}

Future<T?> showAppSheet<T>(BuildContext context, Widget child) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => Padding(
      padding:
          EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
      child: SingleChildScrollView(child: child),
    ),
  );
}

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'حذف',
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('إلغاء'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          style: TextButton.styleFrom(foregroundColor: ctx.debtColor),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}

class SheetTitle extends StatelessWidget {
  const SheetTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .titleLarge
            ?.copyWith(fontWeight: FontWeight.w800),
      ),
    );
  }
}

// ───────────────────────── زبون جديد / تعديل ─────────────────────────

Future<void> showCustomerSheet(BuildContext context, Store store,
    {Customer? existing}) {
  return showAppSheet<void>(
      context, _CustomerForm(store: store, existing: existing));
}

class _CustomerForm extends StatefulWidget {
  const _CustomerForm({required this.store, this.existing});
  final Store store;
  final Customer? existing;

  @override
  State<_CustomerForm> createState() => _CustomerFormState();
}

class _CustomerFormState extends State<_CustomerForm> {
  final TextEditingController _initial = TextEditingController();
  late final TextEditingController _name =
      TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _phone =
      TextEditingController(text: widget.existing?.phone ?? '');
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _initial.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'اكتب اسم الزبون');
      return;
    }
    final phone = cleanPhone(_phone.text);
    final navigator = Navigator.of(context);
    final e = widget.existing;
    if (e == null) {
      await widget.store
          .addCustomer(name, phone, initial: parseAmount(_initial.text) ?? 0);
    } else {
      await widget.store.updateCustomer(e.id, name, phone);
    }
    navigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SheetTitle(editing ? 'تعديل بيانات الزبون' : 'زبون جديد'),
        TextField(
          controller: _name,
          autofocus: !editing,
          textInputAction: TextInputAction.next,
          decoration: fieldDecoration(
            context,
            'اسم الزبون',
            prefix: const Icon(Icons.person_outline_rounded),
            errorText: _error,
          ),
          onChanged: (_) {
            if (_error != null) setState(() => _error = null);
          },
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: fieldDecoration(
            context,
            'رقم الهاتف (اختياري)',
            hint: 'مع رمز الدولة، مثال: 2137xxxxxxxx',
            prefix: const Icon(Icons.phone_outlined),
          ),
        ),
        if (!editing) ...[
          const SizedBox(height: 12),
          TextField(
            controller: _initial,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: fieldDecoration(
              context,
              'كم عليه الآن؟ (اختياري)',
              hint: 'اتركه فارغًا إذا ما عليه شي',
              prefix: const Icon(Icons.account_balance_wallet_outlined),
            ),
          ),
        ],
        const SizedBox(height: 20),
        FilledButton(
          onPressed: _save,
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          child: Text(editing ? 'حفظ التعديل' : 'إضافة الزبون',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}

// ───────────────────────── دين جديد / تسديد ─────────────────────────

Future<TxnInput?> showTxnSheet(BuildContext context,
    {required bool isDebt, required String currency, double? payAll}) {
  return showAppSheet<TxnInput>(
      context, _TxnForm(isDebt: isDebt, currency: currency, payAll: payAll));
}

class _TxnForm extends StatefulWidget {
  const _TxnForm(
      {required this.isDebt, required this.currency, this.payAll});
  final bool isDebt;
  final double? payAll;
  final String currency;

  @override
  State<_TxnForm> createState() => _TxnFormState();
}

class _TxnFormState extends State<_TxnForm> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  void _save() {
    final v = parseAmount(_amount.text);
    if (v == null) {
      setState(() => _error = 'اكتب مبلغًا صحيحًا');
      return;
    }
    Navigator.pop(context, TxnInput(v, _note.text.trim()));
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.isDebt ? context.debtColor : context.paidColor;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SheetTitle(widget.isDebt ? 'تسجيل دين جديد' : 'تسجيل تسديد'),
        TextField(
          controller: _amount,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
          decoration: fieldDecoration(
            context,
            'المبلغ',
            suffixText: widget.currency,
            errorText: _error,
          ),
          onChanged: (_) {
            if (_error != null) setState(() => _error = null);
          },
        ),
        if (!widget.isDebt && widget.payAll != null && widget.payAll! > 0) ...[
          const SizedBox(height: 10),
          OutlinedButton(
            onPressed: () {
              final v = widget.payAll!;
              _amount.text =
                  v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();
              setState(() => _error = null);
            },
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(46),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
            child: Text(
                'تسديد كامل المبلغ (${formatMoney(widget.payAll!, widget.currency)})'),
          ),
        ],
        const SizedBox(height: 12),
        TextField(
          controller: _note,
          textInputAction: TextInputAction.done,
          onSubmitted: (_) => _save(),
          decoration: fieldDecoration(
            context,
            'ملاحظة (اختياري)',
            hint: widget.isDebt ? 'مثال: خبز وحليب' : 'مثال: دفعة نقدية',
            prefix: const Icon(Icons.edit_note_rounded),
          ),
        ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: _save,
          style: FilledButton.styleFrom(
            backgroundColor: color,
            foregroundColor: Colors.white,
            minimumSize: const Size.fromHeight(52),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          child: Text(widget.isDebt ? 'حفظ الدين' : 'حفظ التسديد',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}

// ───────────────────────── الإعدادات ─────────────────────────

Future<void> showSettingsSheet(BuildContext context, Store store) {
  return showAppSheet<void>(context, _SettingsForm(store: store));
}

class _SettingsForm extends StatefulWidget {
  const _SettingsForm({required this.store});
  final Store store;

  @override
  State<_SettingsForm> createState() => _SettingsFormState();
}

class _SettingsFormState extends State<_SettingsForm> {
  late final TextEditingController _shop =
      TextEditingController(text: widget.store.shopName);
  late final TextEditingController _currency =
      TextEditingController(text: widget.store.currency);

  @override
  void dispose() {
    _shop.dispose();
    _currency.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final navigator = Navigator.of(context);
    await widget.store.saveSettings(_shop.text.trim(), _currency.text.trim());
    navigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SheetTitle('الإعدادات'),
        Text('المظهر',
            style: Theme.of(context)
                .textTheme
                .titleSmall
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        ListenableBuilder(
          listenable: widget.store,
          builder: (context, _) => Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SegmentedButton<String>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 'system', label: Text('تلقائي')),
                  ButtonSegment(value: 'light', label: Text('فاتح')),
                  ButtonSegment(value: 'dark', label: Text('داكن')),
                ],
                selected: {widget.store.themeMode},
                onSelectionChanged: (s) => widget.store.setThemeMode(s.first),
              ),
              const SizedBox(height: 16),
              Text('لون التطبيق',
                  style: Theme.of(context)
                      .textTheme
                      .titleSmall
                      ?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (var i = 0; i < accents.length; i++)
                    AccentDot(
                      accent: accents[i],
                      selected: widget.store.accentIndex == i,
                      onTap: () => widget.store.setAccent(i),
                    ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        TextField(
          controller: _shop,
          decoration: fieldDecoration(
            context,
            'اسم المحل',
            hint: 'يظهر في رسالة التذكير',
            prefix: const Icon(Icons.storefront_outlined),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _currency,
          decoration: fieldDecoration(
            context,
            'العملة',
            hint: 'مثال: د.ج  أو  ر.س  أو  ل.س',
            prefix: const Icon(Icons.payments_outlined),
          ),
        ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: _save,
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          child: const Text('حفظ',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        ),
        if (authEnabled) ...[
          const SizedBox(height: 8),
          TextButton(
            onPressed: () async {
              final navigator = Navigator.of(context);
              await Supabase.instance.client.auth.signOut();
              navigator.pop();
            },
            style: TextButton.styleFrom(foregroundColor: context.debtColor),
            child: const Text('تسجيل الخروج'),
          ),
        ],
      ],
    );
  }
}
