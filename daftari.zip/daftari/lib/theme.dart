import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// لون التطبيق الأساسي. صاحب المحل يختار واحدًا من الإعدادات.
class Accent {
  const Accent(this.name, this.primary, this.light, this.deep, this.onDark);

  final String name;
  final Color primary; // اللون الأساسي في الوضع الفاتح
  final Color light; // بداية تدرج البطاقات
  final Color deep; // نهاية تدرج البطاقات
  final Color onDark; // اللون الأساسي في الوضع الداكن
}

const accents = <Accent>[
  Accent('زمردي', Color(0xFF1F6F5C), Color(0xFF2B8C74), Color(0xFF14503F),
      Color(0xFF5FB89F)),
  Accent('أزرق', Color(0xFF2563A6), Color(0xFF3B82C4), Color(0xFF173F6E),
      Color(0xFF7DB3E8)),
  Accent('بنفسجي', Color(0xFF6B4FA0), Color(0xFF8567BD), Color(0xFF45327A),
      Color(0xFFB39DDB)),
  Accent('برتقالي', Color(0xFFB4560C), Color(0xFFD9701F), Color(0xFF7E3F09),
      Color(0xFFF0A35E)),
  Accent('وردي', Color(0xFFB03A6F), Color(0xFFCC4F87), Color(0xFF7C2450),
      Color(0xFFE88DB4)),
  Accent('رمادي', Color(0xFF3D5A6C), Color(0xFF52758B), Color(0xFF28404F),
      Color(0xFF8FB0C4)),
];

/// ألوان الدين والتسديد ثابتة (طوبي وأخضر) حتى يفهمها الجميع مهما كان لون التطبيق.
class AppColors {
  static Accent current = accents.first;
  static Color get primary => current.primary;
  static Color get primaryLight => current.light;
  static Color get primaryDeep => current.deep;
  static const debt = Color(0xFFB5543C);
  static const paid = Color(0xFF2E7D5B);
  static const gold = Color(0xFFD9A441);
}

ThemeData buildTheme(Brightness brightness, Accent accent) {
  final dark = brightness == Brightness.dark;
  final bg = dark ? const Color(0xFF111917) : const Color(0xFFF5F3EC);
  final surface = dark ? const Color(0xFF1A2522) : const Color(0xFFFCFBF7);
  final ink = dark ? const Color(0xFFE6EBE8) : const Color(0xFF24312D);

  final scheme = ColorScheme.fromSeed(
    seedColor: accent.primary,
    brightness: brightness,
  ).copyWith(
    primary: dark ? accent.onDark : accent.primary,
    onPrimary: dark ? const Color(0xFF10151A) : Colors.white,
    surface: surface,
    onSurface: ink,
    error: AppColors.debt,
  );

  final base = ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
  );

  return base.copyWith(
    textTheme: GoogleFonts.cairoTextTheme(base.textTheme)
        .apply(bodyColor: ink, displayColor: ink),
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      foregroundColor: ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.cairo(
        fontSize: 22,
        fontWeight: FontWeight.w800,
        color: ink,
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}

extension Palette on BuildContext {
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
  Color get cardBg => Theme.of(this).colorScheme.surface;
  Color get ink => Theme.of(this).colorScheme.onSurface;
  Color get muted => ink.withOpacity(0.62);
  Color get line => ink.withOpacity(0.09);
  Color get brand => Theme.of(this).colorScheme.primary;
  Color get debtColor => isDark ? const Color(0xFFE08A72) : AppColors.debt;
  Color get paidColor => isDark ? const Color(0xFF6CC49E) : AppColors.paid;
}

/// دائرة لون في إعدادات المظهر.
class AccentDot extends StatelessWidget {
  const AccentDot({
    super.key,
    required this.accent,
    required this.selected,
    required this.onTap,
  });

  final Accent accent;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: accent.name,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: accent.primary,
            border: Border.all(
              color: selected ? context.ink : Colors.transparent,
              width: 3,
            ),
          ),
          child: selected
              ? const Icon(Icons.check_rounded, color: Colors.white)
              : null,
        ),
      ),
    );
  }
}
