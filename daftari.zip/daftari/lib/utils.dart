import 'package:intl/intl.dart';

/// يحوّل الأرقام العربية والفارسية إلى أرقام إنجليزية ويعالج الفواصل.
String normalizeDigits(String input) {
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  final out = StringBuffer();
  for (final ch in input.split('')) {
    final a = arabic.indexOf(ch);
    final f = persian.indexOf(ch);
    if (a >= 0) {
      out.write(a);
    } else if (f >= 0) {
      out.write(f);
    } else if (ch == '٫') {
      out.write('.');
    } else if (ch == ',' || ch == '،' || ch == '٬') {
      // فاصل آلاف: نتجاهله
    } else {
      out.write(ch);
    }
  }
  return out.toString();
}

double? parseAmount(String input) {
  final cleaned = normalizeDigits(input).replaceAll(RegExp(r'\s'), '');
  final v = double.tryParse(cleaned);
  if (v == null || v <= 0) return null;
  return v;
}

String formatMoney(double value, String currency) {
  final f = NumberFormat('#,##0.##', 'en');
  return '${f.format(value.abs())} $currency';
}

String formatDate(DateTime d) => DateFormat('d MMM y', 'ar').format(d);

String formatTime(DateTime d) => DateFormat('h:mm a', 'ar').format(d);

String relativeDay(DateTime d) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final day = DateTime(d.year, d.month, d.day);
  final diff = today.difference(day).inDays;
  if (diff <= 0) return 'اليوم';
  if (diff == 1) return 'أمس';
  if (diff < 30) return 'منذ $diff يوم';
  return formatDate(d);
}

/// يُبقي الأرقام فقط مع الاحتفاظ بعلامة + في البداية إن وُجدت.
String cleanPhone(String raw) {
  final n = normalizeDigits(raw).trim();
  final plus = n.startsWith('+');
  final digits = n.replaceAll(RegExp(r'[^0-9]'), '');
  return plus ? '+$digits' : digits;
}

/// صيغة واتساب: أرقام فقط بدون + ولا 00.
String whatsappNumber(String phone) {
  var d = phone.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('00')) d = d.substring(2);
  return d;
}
