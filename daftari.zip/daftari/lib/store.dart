import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:supabase_flutter/supabase_flutter.dart' show Supabase;

import 'config.dart';
import 'db.dart';
import 'models.dart';

class Store extends ChangeNotifier {
  Store(this._prefs)
      : currency = _prefs.getString('currency') ?? 'د.ج',
        shopName = _prefs.getString('shop') ?? '',
        ownerName = _prefs.getString('owner') ?? '',
        phone = _prefs.getString('shop_phone') ?? '',
        city = _prefs.getString('city') ?? '',
        address = _prefs.getString('address') ?? '',
        shopType = _prefs.getString('shop_type') ?? '',
        lat = _prefs.getDouble('lat'),
        lng = _prefs.getDouble('lng'),
        registered = _prefs.getBool('registered') ?? false,
        mapUrl = _prefs.getString('map_url') ?? '',
        themeMode = _prefs.getString('theme') ?? 'system',
        accentIndex = _prefs.getInt('accent') ?? 0;

  final SharedPreferences _prefs;

  String currency;
  String shopName;
  String ownerName;
  String phone;
  String city;
  String address;
  String shopType;
  double? lat;
  double? lng;
  bool registered;
  String mapUrl;
  String themeMode; // system | light | dark
  int accentIndex;
  double todayDebt = 0;
  double todayPaid = 0;
  List<Customer> customers = [];

  double get totalDebt =>
      customers.fold(0.0, (sum, c) => c.balance > 0 ? sum + c.balance : sum);

  int get debtorsCount => customers.where((c) => c.balance > 0).length;

  Future<void> load() async {
    customers = await Db.instance.customers();
    final today = await Db.instance.todayTotals();
    todayDebt = today[0];
    todayPaid = today[1];
    notifyListeners();
  }

  Future<void> setThemeMode(String mode) async {
    themeMode = mode;
    await _prefs.setString('theme', mode);
    notifyListeners();
  }

  Future<void> setAccent(int index) async {
    accentIndex = index;
    await _prefs.setInt('accent', index);
    notifyListeners();
  }

  Future<void> saveSettings(String newShop, String newCurrency) async {
    shopName = newShop;
    currency = newCurrency.isEmpty ? currency : newCurrency;
    await _prefs.setString('shop', shopName);
    await _prefs.setString('currency', currency);
    notifyListeners();
  }

  Future<void> saveProfile({
    required String shop,
    required String owner,
    required String phone,
    required String city,
    required String address,
    required String type,
    String mapUrl = '',
    double? lat,
    double? lng,
  }) async {
    shopName = shop;
    ownerName = owner;
    this.phone = phone;
    this.city = city;
    this.address = address;
    shopType = type;
    this.mapUrl = mapUrl;
    this.lat = lat;
    this.lng = lng;
    registered = true;
    await _prefs.setString('shop', shop);
    await _prefs.setString('owner', owner);
    await _prefs.setString('shop_phone', phone);
    await _prefs.setString('city', city);
    await _prefs.setString('address', address);
    await _prefs.setString('shop_type', type);
    await _prefs.setString('map_url', mapUrl);
    if (lat != null && lng != null) {
      await _prefs.setDouble('lat', lat);
      await _prefs.setDouble('lng', lng);
    } else {
      await _prefs.remove('lat');
      await _prefs.remove('lng');
    }
    await _prefs.setBool('registered', true);
    await syncProfile();
    notifyListeners();
  }

  /// يرسل بيانات المحل إلى السيرفر. لو ما في إنترنت تبقى محفوظة على الجوال،
  /// ويعاد الإرسال عند فتح التطبيق مرة ثانية.
  Future<void> syncProfile() async {
    if (!authEnabled) return;
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      if (user == null) return;
      await client.from('shops').upsert({
        'id': user.id,
        'email': user.email,
        'shop_name': shopName,
        'owner_name': ownerName,
        'phone': phone,
        'shop_type': shopType,
        'city': city,
        'address': address,
        'lat': lat,
        'lng': lng,
        'map_url': mapUrl,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
    } catch (_) {}
  }

  Future<void> addCustomer(String name, String phone,
      {double initial = 0}) async {
    final id = await Db.instance.addCustomer(name, phone);
    if (initial > 0) {
      await Db.instance.addTxn(id, initial, 'رصيد سابق');
    }
    await load();
  }

  Future<void> updateCustomer(int id, String name, String phone) async {
    await Db.instance.updateCustomer(id, name, phone);
    await load();
  }

  Future<void> deleteCustomer(int id) async {
    await Db.instance.deleteCustomer(id);
    await load();
  }

  Future<List<Txn>> txns(int customerId) => Db.instance.txns(customerId);

  Future<int> addTxn(int customerId, double amount, String note) async {
    final id = await Db.instance.addTxn(customerId, amount, note);
    await load();
    return id;
  }

  Future<void> deleteTxn(int id) async {
    await Db.instance.deleteTxn(id);
    await load();
  }
}
