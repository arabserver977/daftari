import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'models.dart';

/// قاعدة بيانات محلية (SQLite): يشتغل التطبيق بالكامل بدون إنترنت.
class Db {
  Db._();
  static final Db instance = Db._();

  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'daftari.db');
    return openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL,
            FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
          )
        ''');
        await db.execute(
            'CREATE INDEX idx_tx_customer ON transactions(customer_id)');
      },
    );
  }

  double _round(num v) => (v * 100).round() / 100;

  Future<List<Customer>> customers() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT c.id, c.name, c.phone,
             COALESCE(SUM(t.amount), 0) AS balance,
             COALESCE(MAX(t.created_at), c.created_at) AS last_activity
      FROM customers c
      LEFT JOIN transactions t ON t.customer_id = c.id
      GROUP BY c.id
      ORDER BY balance DESC, c.name ASC
    ''');
    return rows
        .map((r) => Customer(
              id: r['id'] as int,
              name: r['name'] as String,
              phone: r['phone'] as String,
              balance: _round(r['balance'] as num),
              lastActivity: DateTime.fromMillisecondsSinceEpoch(
                  r['last_activity'] as int),
            ))
        .toList();
  }

  Future<int> addCustomer(String name, String phone) async {
    final db = await database;
    return db.insert('customers', {
      'name': name,
      'phone': phone,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<void> updateCustomer(int id, String name, String phone) async {
    final db = await database;
    await db.update('customers', {'name': name, 'phone': phone},
        where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteCustomer(int id) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn
          .delete('transactions', where: 'customer_id = ?', whereArgs: [id]);
      await txn.delete('customers', where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<List<Txn>> txns(int customerId) async {
    final db = await database;
    final rows = await db.query(
      'transactions',
      where: 'customer_id = ?',
      whereArgs: [customerId],
      orderBy: 'created_at DESC, id DESC',
    );
    return rows
        .map((r) => Txn(
              id: r['id'] as int,
              customerId: r['customer_id'] as int,
              amount: (r['amount'] as num).toDouble(),
              note: r['note'] as String,
              createdAt:
                  DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int),
            ))
        .toList();
  }

  /// مجموع الديون الجديدة والتسديدات منذ بداية اليوم: [دين, تسديد].
  Future<List<double>> todayTotals() async {
    final db = await database;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(CASE WHEN amount > 0 THEN amount END), 0) AS d,
             COALESCE(SUM(CASE WHEN amount < 0 THEN -amount END), 0) AS p
      FROM transactions WHERE created_at >= ?
    ''', [start]);
    return [
      _round(rows.first['d'] as num),
      _round(rows.first['p'] as num),
    ];
  }

  Future<int> addTxn(int customerId, double amount, String note) async {
    final db = await database;
    return db.insert('transactions', {
      'customer_id': customerId,
      'amount': amount,
      'note': note,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<void> deleteTxn(int id) async {
    final db = await database;
    await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }
}
