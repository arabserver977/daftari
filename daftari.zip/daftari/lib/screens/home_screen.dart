import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import 'customer_screen.dart';
import 'register_screen.dart';

bool _isOverdue(Customer c) =>
    c.balance > 0 && DateTime.now().difference(c.lastActivity).inDays >= 30;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.store});

  final Store store;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _query = '';
  String _filter = 'all';

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final q = _query.trim();
        final base = store.customers.where((c) {
          if (_filter == 'debt') return c.balance > 0;
          if (_filter == 'paid') return c.balance <= 0;
          return true;
        });
        final list = q.isEmpty
            ? base.toList()
            : base
                .where((c) => c.name.contains(q) || c.phone.contains(q))
                .toList();

        return Scaffold(
          appBar: AppBar(
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset('assets/logo.png', height: 34),
                const SizedBox(width: 10),
                const Text('دفتري'),
              ],
            ),
            actions: [
              IconButton(
                tooltip: 'بيانات المحل',
                icon: const Icon(Icons.storefront_outlined),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) =>
                        RegisterScreen(store: store, editing: true),
                  ),
                ),
              ),
              IconButton(
                tooltip: 'الإعدادات',
                icon: const Icon(Icons.tune_rounded),
                onPressed: () => showSettingsSheet(context, store),
              ),
              const SizedBox(width: 4),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => showCustomerSheet(context, store),
            backgroundColor: context.brand,
            foregroundColor: Theme.of(context).colorScheme.onPrimary,
            icon: const Icon(Icons.person_add_alt_1_rounded),
            label: const Text('زبون جديد',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          body: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: _SummaryCard(store: store),
                ),
              ),
              if (store.customers.isNotEmpty)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                    child: TextField(
                      onChanged: (v) => setState(() => _query = v),
                      decoration: fieldDecoration(
                        context,
                        'ابحث عن زبون',
                        prefix: const Icon(Icons.search_rounded),
                      ),
                    ),
                  ),
                ),
              if (store.customers.isNotEmpty)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                    child: Wrap(
                      spacing: 8,
                      children: [
                        for (final f in const [
                          ('all', 'الكل'),
                          ('debt', 'عليهم ديون'),
                          ('paid', 'مسدّدون'),
                        ])
                          ChoiceChip(
                            label: Text(f.$2),
                            selected: _filter == f.$1,
                            onSelected: (_) => setState(() => _filter = f.$1),
                          ),
                      ],
                    ),
                  ),
                ),
              if (store.customers.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: _EmptyState(),
                )
              else if (list.isEmpty)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Center(
                      child: Text('لا يوجد زبون بهذا الاسم',
                          style: TextStyle(color: context.muted)),
                    ),
                  ),
                )
              else
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, i) => Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                      child: _CustomerTile(
                        customer: list[i],
                        currency: store.currency,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => CustomerScreen(
                                store: store, customerId: list[i].id),
                          ),
                        ),
                      ),
                    ),
                    childCount: list.length,
                  ),
                ),
              const SliverToBoxAdapter(child: SizedBox(height: 96)),
            ],
          ),
        );
      },
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.store});
  final Store store;

  @override
  Widget build(BuildContext context) {
    final owing = store.debtorsCount;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.primaryLight, AppColors.primaryDeep],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryDeep.withOpacity(0.25),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('إجمالي الديون المستحقة',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 14,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text(
            formatMoney(store.totalDebt, store.currency),
            style: const TextStyle(
                color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              owing == 0 ? 'لا توجد ديون حاليًا' : '$owing زبون عليهم ديون',
              style: const TextStyle(
                  color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
            ),
          ),
          if (store.todayDebt > 0 || store.todayPaid > 0) ...[
            const SizedBox(height: 12),
            Text(
              'اليوم: دين ${formatMoney(store.todayDebt, store.currency)} • تسديد ${formatMoney(store.todayPaid, store.currency)}',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.85), fontSize: 13),
            ),
          ],
        ],
      ),
    );
  }
}

class _CustomerTile extends StatelessWidget {
  const _CustomerTile({
    required this.customer,
    required this.currency,
    required this.onTap,
  });

  final Customer customer;
  final String currency;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = customer;
    final owes = c.balance > 0;
    final credit = c.balance < 0;
    final color = owes ? context.debtColor : context.paidColor;
    final initial = c.name.isEmpty ? '؟' : c.name.characters.first;

    return Material(
      color: context.cardBg,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: context.line),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: context.brand.withOpacity(0.13),
                child: Text(initial,
                    style: TextStyle(
                        color: context.brand,
                        fontSize: 20,
                        fontWeight: FontWeight.w800)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(c.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(
                      _isOverdue(c)
                          ? 'متأخر • آخر حركة: ${relativeDay(c.lastActivity)}'
                          : 'آخر حركة: ${relativeDay(c.lastActivity)}',
                      style: TextStyle(
                        color: _isOverdue(c) ? context.debtColor : context.muted,
                        fontSize: 12.5,
                        fontWeight:
                            _isOverdue(c) ? FontWeight.w700 : FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (c.balance == 0)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle_rounded,
                            size: 18, color: context.paidColor),
                        const SizedBox(width: 4),
                        Text('مسدّد',
                            style: TextStyle(
                                color: context.paidColor,
                                fontWeight: FontWeight.w700)),
                      ],
                    )
                  else ...[
                    Text(formatMoney(c.balance, currency),
                        style: TextStyle(
                            color: color,
                            fontSize: 17,
                            fontWeight: FontWeight.w800)),
                    Text(credit ? 'له عندك' : 'عليه',
                        style: TextStyle(color: context.muted, fontSize: 12)),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 96),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Opacity(
            opacity: 0.9,
            child: Image.asset('assets/logo.png', height: 110),
          ),
          const SizedBox(height: 20),
          const Text('ابدأ بثلاث خطوات',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(
            'أولًا: اضغط «زبون جديد»\nثانيًا: سجّل الدين عند كل مشتريات\nثالثًا: اضغط «تسديد» لما يدفع',

            textAlign: TextAlign.center,
            style: TextStyle(color: context.muted, height: 1.6),
          ),
        ],
      ),
    );
  }
}
