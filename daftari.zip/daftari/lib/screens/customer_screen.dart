import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';

class CustomerScreen extends StatefulWidget {
  const CustomerScreen({
    super.key,
    required this.store,
    required this.customerId,
  });

  final Store store;
  final int customerId;

  @override
  State<CustomerScreen> createState() => _CustomerScreenState();
}

class _CustomerScreenState extends State<CustomerScreen> {
  List<Txn> _txns = [];

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final t = await widget.store.txns(widget.customerId);
    if (!mounted) return;
    setState(() => _txns = t);
  }

  Customer? get _customer {
    for (final c in widget.store.customers) {
      if (c.id == widget.customerId) return c;
    }
    return null;
  }

  Future<void> _add(bool isDebt) async {
    final input = await showTxnSheet(
      context,
      isDebt: isDebt,
      currency: widget.store.currency,
      payAll: _customer?.balance,
    );
    if (input == null || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    final id = await widget.store.addTxn(
        widget.customerId, isDebt ? input.amount : -input.amount, input.note);
    await _reload();
    messenger.clearSnackBars();
    messenger.showSnackBar(SnackBar(
      content: Text(isDebt ? 'تم تسجيل الدين' : 'تم تسجيل التسديد'),
      action: SnackBarAction(
        label: 'تراجع',
        onPressed: () async {
          await widget.store.deleteTxn(id);
          await _reload();
        },
      ),
    ));
  }

  Future<void> _deleteTxn(Txn t) async {
    final ok = await confirmDialog(
      context,
      title: 'حذف العملية',
      message: 'سيتم حذف هذه العملية من السجل نهائيًا.',
    );
    if (!ok) return;
    await widget.store.deleteTxn(t.id);
    await _reload();
  }

  Future<void> _deleteCustomer(Customer c) async {
    final navigator = Navigator.of(context);
    final ok = await confirmDialog(
      context,
      title: 'حذف الزبون',
      message: 'سيتم حذف "${c.name}" وكل سجلّه نهائيًا.',
    );
    if (!ok) return;
    await widget.store.deleteCustomer(c.id);
    navigator.pop();
  }

  String _reminderText(Customer c) {
    final shop =
        widget.store.shopName.isEmpty ? '' : ' في ${widget.store.shopName}';
    return 'السلام عليكم ${c.name}، تذكير ودّي بأن المتبقي عليكم$shop '
        'هو ${formatMoney(c.balance, widget.store.currency)}. شكرًا لتعاونكم.';
  }

  Future<void> _launch(Uri uri) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok) throw Exception('launch failed');
    } catch (_) {
      messenger.showSnackBar(
        const SnackBar(content: Text('تعذّر فتح التطبيق على هذا الجهاز')),
      );
    }
  }

  void _remind(Customer c) {
    if (c.phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أضف رقم هاتف الزبون أولًا من قائمة التعديل')),
      );
      return;
    }
    final text = Uri.encodeComponent(_reminderText(c));
    showAppSheet<void>(
      context,
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SheetTitle('إرسال تذكير'),
          ListTile(
            leading: const Icon(Icons.chat_rounded),
            title: const Text('واتساب'),
            subtitle: const Text('رسالة جاهزة تُفتح في واتساب'),
            onTap: () {
              Navigator.pop(context);
              _launch(Uri.parse(
                  'https://wa.me/${whatsappNumber(c.phone)}?text=$text'));
            },
          ),
          ListTile(
            leading: const Icon(Icons.sms_rounded),
            title: const Text('رسالة نصية SMS'),
            subtitle: const Text('رسالة جاهزة تُفتح في تطبيق الرسائل'),
            onTap: () {
              Navigator.pop(context);
              _launch(Uri.parse('sms:${c.phone}?body=$text'));
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) {
        final c = _customer;
        if (c == null) return const Scaffold(body: SizedBox.shrink());
        final currency = widget.store.currency;

        return Scaffold(
          appBar: AppBar(
            actions: [
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'edit') {
                    showCustomerSheet(context, widget.store, existing: c);
                  } else if (v == 'delete') {
                    _deleteCustomer(c);
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('تعديل البيانات')),
                  PopupMenuItem(value: 'delete', child: Text('حذف الزبون')),
                ],
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
            children: [
              _Header(customer: c, currency: currency),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _ActionButton(
                      label: 'دين جديد',
                      icon: Icons.add_rounded,
                      color: context.debtColor,
                      onTap: () => _add(true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ActionButton(
                      label: 'تسديد',
                      icon: Icons.check_rounded,
                      color: context.paidColor,
                      onTap: () => _add(false),
                    ),
                  ),
                ],
              ),
              if (c.phone.isNotEmpty) ...[
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () => _launch(Uri.parse('tel:${c.phone}')),
                  icon: const Icon(Icons.call_outlined),
                  label: const Text('اتصال بالزبون'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    side: BorderSide(color: context.line.withOpacity(0.25)),
                  ),
                ),
              ],
              if (c.balance > 0) ...[
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () => _remind(c),
                  icon: const Icon(Icons.notifications_active_outlined),
                  label: const Text('إرسال تذكير للزبون'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    side: BorderSide(color: context.line.withOpacity(0.25)),
                  ),
                ),
              ],
              const SizedBox(height: 24),
              Text('سجل العمليات',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              if (_txns.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 32),
                  child: Center(
                    child: Text('لا توجد عمليات بعد',
                        style: TextStyle(color: context.muted)),
                  ),
                )
              else
                ..._txns.map((t) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _TxnTile(
                        txn: t,
                        currency: currency,
                        onLongPress: () => _deleteTxn(t),
                      ),
                    )),
              if (_txns.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Center(
                    child: Text('اضغط مطولًا على أي عملية لحذفها',
                        style: TextStyle(color: context.muted, fontSize: 12)),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.customer, required this.currency});
  final Customer customer;
  final String currency;

  @override
  Widget build(BuildContext context) {
    final c = customer;
    final String label;
    if (c.balance > 0) {
      label = 'المتبقي عليه';
    } else if (c.balance < 0) {
      label = 'رصيد لصالحه عندك';
    } else {
      label = 'الحساب مسدّد';
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.primaryLight, AppColors.primaryDeep],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(c.name,
              style: const TextStyle(
                  color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
          if (c.phone.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: Text(c.phone,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.75), fontSize: 13)),
              ),
            ),
          const SizedBox(height: 16),
          Text(label,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 14,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(
            c.balance == 0 ? formatMoney(0, currency) : formatMoney(c.balance, currency),
            style: const TextStyle(
                color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800),
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return FilledButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(label,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
      style: FilledButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}

class _TxnTile extends StatelessWidget {
  const _TxnTile({
    required this.txn,
    required this.currency,
    required this.onLongPress,
  });

  final Txn txn;
  final String currency;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    final isDebt = txn.isDebt;
    final color = isDebt ? context.debtColor : context.paidColor;
    final title = txn.note.isNotEmpty ? txn.note : (isDebt ? 'دين' : 'تسديد');

    return Material(
      color: context.cardBg,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: context.line),
      ),
      child: InkWell(
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              CircleAvatar(
                radius: 19,
                backgroundColor: color.withOpacity(0.14),
                child: Icon(
                  isDebt ? Icons.north_east_rounded : Icons.south_west_rounded,
                  size: 18,
                  color: color,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 15.5, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text('${formatDate(txn.createdAt)} • ${formatTime(txn.createdAt)}',
                        style: TextStyle(color: context.muted, fontSize: 12)),
                  ],
                ),
              ),
              Text(
                '${isDebt ? '+' : '−'} ${formatMoney(txn.amount, currency)}',
                style: TextStyle(
                    color: color, fontSize: 16, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
