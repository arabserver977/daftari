import 'package:flutter/material.dart';

import '../maps_link.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets/common.dart';

const _shopTypes = [
  'بقالة',
  'مخبزة',
  'صيدلية',
  'خضر ولحوم',
  'مقهى ومطعم',
  'أخرى',
];

/// شاشة تسجيل بيانات المحل. تظهر بعد الدخول بالإيميل، ويمكن فتحها لاحقًا للتعديل.
/// صاحب المحل يكتب بياناته بنفسه، ولا يطلب التطبيق إذن الموقع أبدًا.
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key, required this.store, this.editing = false});

  final Store store;
  final bool editing;

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  late final TextEditingController _shop =
      TextEditingController(text: widget.store.shopName);
  late final TextEditingController _owner =
      TextEditingController(text: widget.store.ownerName);
  late final TextEditingController _phone =
      TextEditingController(text: widget.store.phone);
  late final TextEditingController _city =
      TextEditingController(text: widget.store.city);
  late final TextEditingController _address =
      TextEditingController(text: widget.store.address);
  late final TextEditingController _map =
      TextEditingController(text: widget.store.mapUrl);
  late String _type = widget.store.shopType;
  late double? _lat = widget.store.lat;
  late double? _lng = widget.store.lng;
  bool _fetching = false;
  bool _mapOk = false;
  String? _mapMsg;
  String? _error;

  @override
  void dispose() {
    _shop.dispose();
    _owner.dispose();
    _phone.dispose();
    _city.dispose();
    _address.dispose();
    _map.dispose();
    super.dispose();
  }

  Future<void> _fetch() async {
    final raw = _map.text.trim();
    if (raw.isEmpty) {
      setState(() {
        _mapOk = false;
        _mapMsg = 'الصق الرابط أولًا';
      });
      return;
    }
    setState(() {
      _fetching = true;
      _mapMsg = null;
    });
    final info = await resolveMapsLink(raw);
    if (!mounted) return;
    setState(() {
      _fetching = false;
      if (info == null) {
        _mapOk = false;
        _mapMsg =
            'ما قدرت أقرأ الرابط. تأكد أنه رابط من خرائط جوجل، أو اكتب البيانات بنفسك.';
        return;
      }
      final parts = <String>[];
      if (info.name != null) {
        parts.add('الاسم: ${info.name}');
        if (_shop.text.trim().isEmpty) _shop.text = info.name!;
      }
      if (info.lat != null && info.lng != null) {
        _lat = info.lat;
        _lng = info.lng;
        parts.add('تم حفظ الموقع');
      }
      _mapOk = true;
      _mapMsg = 'تم التعرف على: ${parts.join(' • ')}';
    });
  }

  Future<void> _save() async {
    final shop = _shop.text.trim();
    if (shop.isEmpty) {
      setState(() => _error = 'اكتب اسم المحل');
      return;
    }
    final navigator = Navigator.of(context);
    await widget.store.saveProfile(
      shop: shop,
      owner: _owner.text.trim(),
      phone: _phone.text.trim(),
      city: _city.text.trim(),
      address: _address.text.trim(),
      type: _type,
      mapUrl: _map.text.trim(),
      lat: _lat,
      lng: _lng,
    );
    if (widget.editing) navigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.editing ? AppBar(title: const Text('بيانات المحل')) : null,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          children: [
            if (!widget.editing) ...[
              Center(child: Image.asset('assets/logo.png', height: 84)),
              const SizedBox(height: 14),
              const Center(
                child: Text('أهلًا بك في دفتري',
                    style:
                        TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              ),
              const SizedBox(height: 6),
              Center(
                child: Text('سجّل بيانات محلك لتبدأ',
                    style: TextStyle(color: context.muted)),
              ),
              const SizedBox(height: 24),
            ],
            TextField(
              controller: _shop,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration(context, 'اسم المحل',
                  prefix: const Icon(Icons.storefront_outlined)),
              onChanged: (_) => setState(() => _error = null),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _owner,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration(context, 'اسم صاحب المحل (اختياري)',
                  prefix: const Icon(Icons.person_outline_rounded)),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration(context, 'رقم الهاتف (اختياري)',
                  hint: 'مع رمز الدولة، مثال: 2137xxxxxxxx',
                  prefix: const Icon(Icons.phone_outlined)),
            ),
            const SizedBox(height: 18),
            Text('نوع المحل',
                style: Theme.of(context)
                    .textTheme
                    .titleSmall
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final t in _shopTypes)
                  ChoiceChip(
                    label: Text(t),
                    selected: _type == t,
                    onSelected: (_) => setState(() => _type = t),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            TextField(
              controller: _city,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration(context, 'المدينة أو الحي (اختياري)',
                  prefix: const Icon(Icons.location_city_outlined)),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _address,
              textInputAction: TextInputAction.next,
              decoration: fieldDecoration(context, 'العنوان (اختياري)',
                  prefix: const Icon(Icons.signpost_outlined)),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _map,
              keyboardType: TextInputType.url,
              textDirection: TextDirection.ltr,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _fetch(),
              decoration: fieldDecoration(
                  context, 'رابط المحل في خرائط جوجل (اختياري)',
                  hint: 'https://maps.app.goo.gl/...',
                  prefix: const Icon(Icons.link_rounded)),
              onChanged: (_) {
                _lat = null;
                _lng = null;
                if (_mapMsg != null) setState(() => _mapMsg = null);
              },
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _fetching ? null : _fetch,
              icon: _fetching
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.download_rounded),
              label: const Text('جلب البيانات من الرابط'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                side: BorderSide(color: context.line.withOpacity(0.25)),
              ),
            ),
            if (_mapMsg != null) ...[
              const SizedBox(height: 8),
              Text(_mapMsg!,
                  style: TextStyle(
                      color: _mapOk ? context.paidColor : context.debtColor,
                      fontWeight: FontWeight.w600)),
            ],
            const SizedBox(height: 6),
            Text(
                'افتح محلك في خرائط جوجل، اضغط مشاركة، وانسخ الرابط. نأخذ منه اسم المحل وموقعه بدون ما نطلب إذن الموقع.',
                style: TextStyle(color: context.muted, fontSize: 12.5, height: 1.5)),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!,
                  style: TextStyle(
                      color: context.debtColor, fontWeight: FontWeight.w600)),
            ],
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _save,
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              child: Text(widget.editing ? 'حفظ' : 'ابدأ الاستخدام',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }
}
