import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';

/// تسجيل الدخول بالإيميل: الخطوة الأولى يكتب إيميله، الثانية يكتب الكود اللي وصله.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _code = TextEditingController();
  bool _sent = false;
  bool _busy = false;
  String? _error;
  int _cooldown = 0;
  Timer? _timer;

  static final _emailRe = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$');

  @override
  void dispose() {
    _timer?.cancel();
    _email.dispose();
    _code.dispose();
    super.dispose();
  }

  void _fail(String msg) {
    if (!mounted) return;
    setState(() => _error = msg);
  }

  void _startCooldown() {
    _cooldown = 60;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() => _cooldown--);
      if (_cooldown <= 0) t.cancel();
    });
  }

  Future<void> _send() async {
    final email = _email.text.trim();
    if (!_emailRe.hasMatch(email)) {
      _fail('اكتب إيميلًا صحيحًا');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await Supabase.instance.client.auth
          .signInWithOtp(email: email, shouldCreateUser: true);
      if (!mounted) return;
      setState(() {
        _sent = true;
        _code.clear();
      });
      _startCooldown();
    } on AuthException catch (e) {
      final m = e.message.toLowerCase();
      _fail(m.contains('rate') || m.contains('seconds')
          ? 'طلبت كودات كثيرة، انتظر قليلًا ثم جرّب'
          : 'تعذّر إرسال الكود، تأكد من الإيميل وجرّب مرة ثانية');
    } catch (_) {
      _fail('تعذّر الاتصال، تأكد من الإنترنت وجرّب مرة ثانية');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _verify() async {
    final token = normalizeDigits(_code.text).trim();
    if (token.length < 6) {
      _fail('اكتب الكود كاملًا');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      // عند النجاح يتغير الـ session ويفتح التطبيق تلقائيًا.
      await Supabase.instance.client.auth.verifyOTP(
        type: OtpType.email,
        email: _email.text.trim(),
        token: token,
      );
    } on AuthException {
      _fail('الكود غير صحيح أو انتهت صلاحيته');
    } catch (_) {
      _fail('تعذّر الاتصال، تأكد من الإنترنت وجرّب مرة ثانية');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
          children: [
            Center(child: Image.asset('assets/logo.png', height: 84)),
            const SizedBox(height: 14),
            const Center(
              child: Text('تسجيل الدخول',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            ),
            const SizedBox(height: 6),
            Center(
              child: Text(
                _sent
                    ? 'أرسلنا كودًا إلى ${_email.text.trim()}\nاكتبه هنا'
                    : 'اكتب إيميلك ونرسل لك كود تأكيد',
                textAlign: TextAlign.center,
                style: TextStyle(color: context.muted, height: 1.6),
              ),
            ),
            const SizedBox(height: 24),
            if (!_sent)
              TextField(
                controller: _email,
                autofocus: true,
                keyboardType: TextInputType.emailAddress,
                textDirection: TextDirection.ltr,
                autofillHints: const [AutofillHints.email],
                onSubmitted: (_) => _send(),
                decoration: fieldDecoration(
                  context,
                  'الإيميل',
                  hint: 'name@example.com',
                  prefix: const Icon(Icons.mail_outline_rounded),
                  errorText: _error,
                ),
                onChanged: (_) {
                  if (_error != null) setState(() => _error = null);
                },
              )
            else
              TextField(
                controller: _code,
                autofocus: true,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                textDirection: TextDirection.ltr,
                maxLength: 10,
                autofillHints: const [AutofillHints.oneTimeCode],
                style: const TextStyle(
                    fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 8),
                onSubmitted: (_) => _verify(),
                decoration: fieldDecoration(
                  context,
                  'الكود',
                  errorText: _error,
                ).copyWith(counterText: ''),
                onChanged: (_) {
                  if (_error != null) setState(() => _error = null);
                },
              ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _busy ? null : (_sent ? _verify : _send),
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              child: _busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.4))
                  : Text(_sent ? 'تأكيد' : 'أرسل الكود',
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700)),
            ),
            if (_sent) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: (_busy || _cooldown > 0) ? null : _send,
                      child: Text(_cooldown > 0
                          ? 'إعادة الإرسال بعد $_cooldown ث'
                          : 'إعادة إرسال الكود'),
                    ),
                  ),
                  Expanded(
                    child: TextButton(
                      onPressed: _busy
                          ? null
                          : () => setState(() {
                                _sent = false;
                                _error = null;
                              }),
                      child: const Text('تغيير الإيميل'),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 8),
            Text('لو ما وصل الكود شوف مجلد الرسائل غير المرغوبة (Spam).',
                textAlign: TextAlign.center,
                style: TextStyle(color: context.muted, fontSize: 12.5)),
          ],
        ),
      ),
    );
  }
}
