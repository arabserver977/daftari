-- شغّل هذا الملف مرة واحدة: Supabase > SQL Editor > New query > الصق > Run
-- جدول المحلات: كل محل يقدر يقرأ ويعدّل بياناته فقط.
-- أنت (صاحب المشروع) ترى كل المحلات من Table Editor في لوحة Supabase.

create table if not exists public.shops (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  shop_name text not null,
  owner_name text,
  phone text,
  shop_type text,
  city text,
  address text,
  map_url text,
  lat double precision,
  lng double precision,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- لو كنت شغّلت النسخة السابقة من الملف، هذا السطر يضيف عمود رابط الخريطة
alter table public.shops add column if not exists map_url text;

alter table public.shops enable row level security;

drop policy if exists "shop owner can read" on public.shops;
drop policy if exists "shop owner can insert" on public.shops;
drop policy if exists "shop owner can update" on public.shops;

create policy "shop owner can read" on public.shops
  for select to authenticated using (auth.uid() = id);

create policy "shop owner can insert" on public.shops
  for insert to authenticated with check (auth.uid() = id);

create policy "shop owner can update" on public.shops
  for update to authenticated
  using (auth.uid() = id) with check (auth.uid() = id);
